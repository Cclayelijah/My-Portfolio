
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cclayelijah',
  applicationName: 'contact-form-api',
  appUid: 'ZSDgSksjxVksfwC8fv',
  orgUid: '710485cb-7323-4340-bb0b-7675d5a7b88c',
  deploymentUid: '039a880e-13e3-4c44-be40-2081bf517024',
  serviceName: 'contact-form-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'contact-form-api-dev-send', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.send, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}